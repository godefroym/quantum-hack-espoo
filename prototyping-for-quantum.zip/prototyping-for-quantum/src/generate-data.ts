import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import Graph from 'graphology';
import louvain from 'graphology-communities-louvain';
import { mulberry32, makeNormal, invNorm } from './rng';
import { buildCompanies, FACTOR_NAMES, NUM_FACTORS } from './model';
import { apriori, eigenvectorCentrality, type WeightedEdge } from './analysis';
import type {
  CommunityInfo,
  EdgeDatum,
  GraphData,
  Itemset,
  NodeDatum,
} from './types';

const SHOTS = 300_000;
const SEED = 0xc0ffee;
const SHIP_PHI_FLOOR = 0.035; // drop near-zero (noise) pairs from the shipped graph
const LOUVAIN_PHI_FLOOR = 0.04; // edges that define community structure

function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const idx = (sorted.length - 1) * q;
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

function main(): void {
  const { companies, hubId } = buildCompanies();
  const n = companies.length;

  const tau = companies.map((c) => invNorm(c.pd));
  const sigma = companies.map((c) => Math.sqrt(Math.max(1e-9, 1 - c.load.reduce((a, v) => a + v * v, 0))));
  const load = companies.map((c) => c.load);

  const rand = mulberry32(SEED);
  const normal = makeNormal(rand);

  // ---- Sample the "circuit" -------------------------------------------------
  const counts = new Int32Array(n); // single-failure counts
  const co = new Float64Array(n * n); // pairwise co-failure counts (upper triangle)
  const maskLo = new Int32Array(SHOTS);
  const maskHi = new Int32Array(SHOTS);
  const Z = new Float64Array(NUM_FACTORS);
  let noFailure = 0;

  console.log(`Sampling ${SHOTS.toLocaleString()} shots over ${n} institutions...`);
  for (let s = 0; s < SHOTS; s++) {
    for (let f = 0; f < NUM_FACTORS; f++) Z[f] = normal();
    let lo = 0;
    let hi = 0;
    const fired: number[] = [];
    for (let i = 0; i < n; i++) {
      let x = sigma[i] * normal();
      const L = load[i];
      for (let f = 0; f < NUM_FACTORS; f++) x += L[f] * Z[f];
      if (x < tau[i]) {
        counts[i]++;
        if (i < 32) lo |= 1 << i;
        else hi |= 1 << (i - 32);
        fired.push(i);
      }
    }
    maskLo[s] = lo;
    maskHi[s] = hi;
    if (fired.length === 0) noFailure++;
    for (let a = 0; a < fired.length; a++) {
      const ia = fired[a];
      for (let b = a + 1; b < fired.length; b++) co[ia * n + fired[b]]++;
    }
  }

  // ---- Reduce to sufficient statistics -------------------------------------
  const marginal = Array.from(counts, (c) => c / SHOTS);
  const edges: EdgeDatum[] = [];
  const posEdges: WeightedEdge[] = []; // for centrality (all positive phi)
  const phiVals: number[] = [];

  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const pij = co[i * n + j] / SHOTS;
      const pi = marginal[i];
      const pj = marginal[j];
      const denom = Math.sqrt(pi * (1 - pi) * pj * (1 - pj));
      if (denom <= 0) continue;
      const phi = (pij - pi * pj) / denom;
      if (phi > 0) posEdges.push({ i, j, w: phi });
      // hedges are ~5x weaker than contagion; only ship the meaningful ones
      const shipFloor = phi > 0 ? SHIP_PHI_FLOOR : 0.05;
      if (Math.abs(phi) < shipFloor) continue;
      phiVals.push(phi);
      // orient source -> target as driver(rarer) -> dependent(commoner)
      const lowFirst = pi <= pj;
      const sIdx = lowFirst ? i : j;
      const tIdx = lowFirst ? j : i;
      const pS = marginal[sIdx];
      const pT = marginal[tIdx];
      edges.push({
        source: sIdx,
        target: tIdx,
        phi,
        lift: pi * pj > 0 ? pij / (pi * pj) : 0,
        pBoth: pij,
        pSource: pS,
        pTarget: pT,
        confST: pS > 0 ? pij / pS : 0,
        confTS: pT > 0 ? pij / pT : 0,
      });
    }
  }

  // ---- Eigenvector centrality (systemic importance) ------------------------
  const centrality = eigenvectorCentrality(n, posEdges);

  // ---- Community detection (Louvain) — discovered, not the planted sectors -
  const g = new Graph({ type: 'undirected' });
  for (let i = 0; i < n; i++) g.addNode(String(i));
  for (const e of posEdges) {
    if (e.w >= LOUVAIN_PHI_FLOOR && !g.hasEdge(String(e.i), String(e.j))) {
      g.addEdge(String(e.i), String(e.j), { weight: e.w });
    }
  }
  const rawComm = louvain(g, { getEdgeWeight: 'weight', resolution: 1.0 });
  // relabel communities 0..C-1 by descending size for stable colors
  const sizeByRaw = new Map<number, number>();
  for (let i = 0; i < n; i++) {
    const c = rawComm[String(i)];
    sizeByRaw.set(c, (sizeByRaw.get(c) ?? 0) + 1);
  }
  const order = [...sizeByRaw.entries()].sort((a, b) => b[1] - a[1]).map((e) => e[0]);
  const remap = new Map<number, number>(order.map((raw, idx) => [raw, idx]));
  const community = new Array<number>(n);
  for (let i = 0; i < n; i++) community[i] = remap.get(rawComm[String(i)]) ?? 0;

  // ---- Assemble nodes ------------------------------------------------------
  const nodes: NodeDatum[] = companies.map((c) => ({
    id: c.id,
    label: c.label,
    sector: c.sector,
    sectorName: c.sectorName,
    pd: c.pd,
    marginal: marginal[c.id],
    centrality: centrality[c.id],
    community: community[c.id],
  }));

  // ---- Community summaries -------------------------------------------------
  const byComm = new Map<number, number[]>();
  for (let i = 0; i < n; i++) {
    if (!byComm.has(community[i])) byComm.set(community[i], []);
    byComm.get(community[i])!.push(i);
  }
  const communities: CommunityInfo[] = [...byComm.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([id, members]) => {
      const counts2 = new Map<string, number>();
      for (const m of members) counts2.set(nodes[m].sector, (counts2.get(nodes[m].sector) ?? 0) + 1);
      const [domSector, domCount] = [...counts2.entries()].sort((a, b) => b[1] - a[1])[0];
      return {
        id,
        members,
        size: members.length,
        dominantSector: domSector,
        dominantSectorName: nodes[members.find((m) => nodes[m].sector === domSector)!].sectorName,
        purity: domCount / members.length,
        avgMarginal: members.reduce((a, m) => a + marginal[m], 0) / members.length,
      };
    });

  // ---- Higher-order co-failure blocs (Apriori) -----------------------------
  console.log('Mining co-failure blocs (Apriori)...');
  const allItemsets = apriori(maskLo, maskHi, SHOTS, n, marginal, 0.03, 4);
  const itemsets: Itemset[] = allItemsets
    .sort((a, b) => b.support - a.support)
    .slice(0, 30)
    .map((it) => ({ ...it, labels: it.members.map((m) => nodes[m].label) }));

  // ---- Meta ----------------------------------------------------------------
  const absSorted = phiVals.map(Math.abs).sort((a, b) => a - b);
  const posSorted = phiVals.filter((v) => v > 0).sort((a, b) => a - b);
  const negSorted = phiVals.filter((v) => v < 0).map((v) => -v).sort((a, b) => a - b);
  const meta = {
    n,
    shots: SHOTS,
    factorNames: FACTOR_NAMES,
    pNoFailure: noFailure / SHOTS,
    expectedFailures: marginal.reduce((a, v) => a + v, 0),
    maxAbsPhi: absSorted.length ? absSorted[absSorted.length - 1] : 1,
    posPhiScale: quantile(posSorted, 0.97) || 0.5,
    negPhiScale: quantile(negSorted, 0.97) || 0.1,
    defaultThreshold: 0.2, // normalized association strength (|phi| / per-sign scale), not raw phi
    note:
      'Pairwise phi-correlations from a Gaussian-copula factor model sampled as ' +
      'quantum shots. Edge hue = sign/strength of co-failure correlation; ' +
      'brightness runs driver->dependent (direction of implication). With this ' +
      'many shots, pairwise sampling error is <0.001 — the genuinely uncertain ' +
      'structure lives in the higher-order blocs.',
  };

  const data: GraphData = { meta, nodes, edges, itemsets, communities };

  const here = dirname(fileURLToPath(import.meta.url));
  const outPath = join(here, 'data.json');
  writeFileSync(outPath, JSON.stringify(data));

  report(data, hubId);
  console.log(`\nWrote ${outPath} (${edges.length} edges, ${itemsets.length} blocs).`);
}

function report(data: GraphData, hubId: number): void {
  const { nodes, edges, communities, meta, itemsets } = data;
  const sectors = [...new Set(nodes.map((d) => d.sector))];

  console.log('\n=== validation report ===');
  console.log(`P(no failure) = ${(meta.pNoFailure * 100).toFixed(1)}%`);
  console.log(`E[simultaneous failures] = ${meta.expectedFailures.toFixed(2)}`);

  console.log('\nmean observed marginal by sector (should track planted PD):');
  for (const sec of sectors) {
    const ns = nodes.filter((d) => d.sector === sec);
    const m = ns.reduce((a, d) => a + d.marginal, 0) / ns.length;
    console.log(`  ${sec} ${ns[0].sectorName.padEnd(18)} ${(m * 100).toFixed(1)}%`);
  }

  console.log('\ndetected community vs planted sector (purity = did Louvain recover sectors?):');
  for (const c of communities) {
    const comp = sectors
      .map((s) => `${s}:${c.members.filter((m) => nodes[m].sector === s).length}`)
      .filter((x) => !x.endsWith(':0'))
      .join('  ');
    console.log(
      `  community ${c.id} (n=${c.size}, ${c.dominantSector} purity ${(c.purity * 100).toFixed(0)}%):  ${comp}`,
    );
  }

  console.log('\ntop systemic (eigenvector centrality):');
  [...nodes]
    .sort((a, b) => b.centrality - a.centrality)
    .slice(0, 5)
    .forEach((d) =>
      console.log(`  ${d.label.padEnd(6)} cen=${d.centrality.toFixed(2)} marg=${(d.marginal * 100).toFixed(1)}% ${d.label.startsWith('GB1') ? '<- planted hub' : ''}`),
    );
  console.log(`  (planted hub id=${hubId})`);

  // hedge check: average phi across the Asset Manager / Crypto boundary
  const amCr = edges.filter((e) => {
    const a = nodes[e.source].sector;
    const b = nodes[e.target].sector;
    return (a === 'AM' && b === 'CR') || (a === 'CR' && b === 'AM');
  });
  const amCrPhi = amCr.length ? amCr.reduce((a, e) => a + e.phi, 0) / amCr.length : 0;
  console.log(`\nAsset-Manager <-> Crypto edges: ${amCr.length}, mean phi = ${amCrPhi.toFixed(3)} (expect negative = hedge)`);

  const pos = edges.filter((e) => e.phi > 0).length;
  const neg = edges.length - pos;
  const strong = edges.filter((e) => Math.abs(e.phi) >= 0.07).length;
  console.log(`\nedges: ${edges.length} total (${pos} contagion / ${neg} hedge); ${strong} with |phi| >= 0.07`);
  console.log(`phi: max=${meta.maxAbsPhi.toFixed(3)}  posScale(97%)=${meta.posPhiScale.toFixed(3)}  negScale(97%)=${meta.negPhiScale.toFixed(3)}`);

  console.log('\ntop co-failure blocs:');
  itemsets.slice(0, 6).forEach((it) =>
    console.log(`  {${it.labels.join(', ')}}  support=${(it.support * 100).toFixed(1)}%  lift=${it.lift.toFixed(1)}`),
  );
}

main();
