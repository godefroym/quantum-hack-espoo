import type { Itemset } from './types';

export interface WeightedEdge {
  i: number;
  j: number;
  w: number;
}

/**
 * Eigenvector centrality via power iteration on the positive-correlation
 * adjacency. Rewards being strongly tied to *other strongly-tied* nodes —
 * i.e. systemic importance, not just raw degree. Returned in [0, 1].
 */
export function eigenvectorCentrality(n: number, edges: WeightedEdge[]): number[] {
  const nbr: Array<Array<[number, number]>> = Array.from({ length: n }, () => []);
  for (const { i, j, w } of edges) {
    if (w <= 0 || i === j) continue;
    nbr[i].push([j, w]);
    nbr[j].push([i, w]);
  }
  let v = new Array<number>(n).fill(1 / Math.sqrt(n));
  for (let it = 0; it < 300; it++) {
    const nv = new Array<number>(n).fill(0);
    for (let i = 0; i < n; i++) {
      const row = nbr[i];
      let acc = 0;
      for (let k = 0; k < row.length; k++) acc += row[k][1] * v[row[k][0]];
      nv[i] = acc;
    }
    let norm = 0;
    for (let i = 0; i < n; i++) norm += nv[i] * nv[i];
    norm = Math.sqrt(norm) || 1;
    for (let i = 0; i < n; i++) nv[i] /= norm;
    v = nv;
  }
  let max = 0;
  for (let i = 0; i < n; i++) max = Math.max(max, Math.abs(v[i]));
  max = max || 1;
  return v.map((x) => Math.abs(x) / max);
}

function maskOf(members: number[]): [number, number] {
  let lo = 0;
  let hi = 0;
  for (const id of members) {
    if (id < 32) lo |= 1 << id;
    else hi |= 1 << (id - 32);
  }
  return [lo >>> 0, hi >>> 0];
}

function countMask(
  loArr: Int32Array,
  hiArr: Int32Array,
  N: number,
  lo: number,
  hi: number,
): number {
  let c = 0;
  for (let s = 0; s < N; s++) {
    if ((loArr[s] & lo) === lo && (hiArr[s] & hi) === hi) c++;
  }
  return c;
}

const key = (a: number[]): string => a.join(',');

/**
 * Apriori frequent-itemset mining over the shots (each shot is a "basket" of
 * failed institutions). Surfaces the higher-order co-failure blocs that a
 * purely pairwise graph throws away. Returns itemsets of size >= 2.
 */
export function apriori(
  loArr: Int32Array,
  hiArr: Int32Array,
  N: number,
  n: number,
  marginals: number[],
  minSupportProb = 0.03,
  maxSize = 4,
): Itemset[] {
  const minSup = Math.ceil(minSupportProb * N);
  const out: Itemset[] = [];

  let prev: number[][] = [];
  for (let i = 0; i < n; i++) {
    if (Math.round(marginals[i] * N) >= minSup) prev.push([i]);
  }
  let prevSet = new Set(prev.map(key));

  for (let sz = 2; sz <= maxSize; sz++) {
    const cands: number[][] = [];
    for (let a = 0; a < prev.length; a++) {
      for (let b = a + 1; b < prev.length; b++) {
        const A = prev[a];
        const B = prev[b];
        let share = true;
        for (let t = 0; t < sz - 2; t++) {
          if (A[t] !== B[t]) {
            share = false;
            break;
          }
        }
        if (!share || A[sz - 2] >= B[sz - 2]) continue;
        const cand = [...A, B[sz - 2]];
        // prune: every (sz-1)-subset must itself be frequent
        let ok = true;
        for (let r = 0; r < cand.length && ok; r++) {
          const sub = cand.slice(0, r).concat(cand.slice(r + 1));
          if (!prevSet.has(key(sub))) ok = false;
        }
        if (ok) cands.push(cand);
      }
    }
    if (cands.length === 0 || cands.length > 6000) break; // bound the work

    const cur: number[][] = [];
    for (const cand of cands) {
      const [lo, hi] = maskOf(cand);
      const c = countMask(loArr, hiArr, N, lo, hi);
      if (c >= minSup) {
        cur.push(cand);
        const support = c / N;
        let expProd = 1;
        for (const id of cand) expProd *= marginals[id];
        out.push({
          members: cand,
          labels: [],
          support,
          lift: expProd > 0 ? support / expProd : 0,
          size: cand.length,
        });
      }
    }
    prev = cur;
    prevSet = new Set(prev.map(key));
    if (prev.length === 0) break;
  }
  return out;
}
