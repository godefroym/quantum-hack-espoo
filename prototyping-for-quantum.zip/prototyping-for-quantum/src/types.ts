// ---------------------------------------------------------------------------
// Data contract: the page never sees the 300k raw shots. The generator reduces
// them to these sufficient statistics (marginals + pairwise moments + a few
// derived structures) and ships only this — a few thousand numbers.
// ---------------------------------------------------------------------------

export interface NodeDatum {
  id: number;
  label: string;
  sector: string; // sector key, e.g. "GB"
  sectorName: string;
  pd: number; // planted (ground-truth) default probability
  marginal: number; // observed P(this institution fails) = node fragility
  centrality: number; // eigenvector centrality in [0,1] = systemic importance
  community: number; // data-detected community (Louvain), not the planted sector
  // mutated at runtime by d3-force:
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
  fx?: number | null;
  fy?: number | null;
}

export interface EdgeDatum {
  source: number; // node id with the LOWER marginal (the "driver" / rarer failure)
  target: number; // node id with the higher marginal (the "dependent")
  phi: number; // signed phi correlation coefficient (the hero signal)
  lift: number; // P(both) / (P(i)P(j)); >1 contagion, <1 mutual-exclusion
  pBoth: number; // P(both fail)
  pSource: number; // P(source fails)
  pTarget: number; // P(target fails)
  confST: number; // P(target fails | source fails)
  confTS: number; // P(source fails | target fails)
}

export interface Itemset {
  members: number[];
  labels: string[];
  support: number; // P(all members fail together)
  lift: number; // support / product of marginals (surprise vs independence)
  size: number;
}

export interface CommunityInfo {
  id: number;
  members: number[];
  size: number;
  dominantSector: string;
  dominantSectorName: string;
  purity: number; // fraction of members in the dominant sector
  avgMarginal: number;
}

export interface GraphMeta {
  n: number;
  shots: number;
  factorNames: string[];
  pNoFailure: number; // P(nobody fails)
  expectedFailures: number; // mean number of simultaneous failures
  maxAbsPhi: number;
  posPhiScale: number; // normalization for positive (contagion) edge color
  negPhiScale: number; // normalization for negative (hedge) edge color
  defaultThreshold: number; // suggested initial |phi| cutoff for the backbone
  note: string;
}

export interface GraphData {
  meta: GraphMeta;
  nodes: NodeDatum[];
  edges: EdgeDatum[];
  itemsets: Itemset[];
  communities: CommunityInfo[];
}
