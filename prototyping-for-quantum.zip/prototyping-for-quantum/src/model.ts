import { mulberry32 } from './rng';

// ---------------------------------------------------------------------------
// Synthetic "quantum circuit" = a Gaussian-copula factor model of correlated
// defaults (the standard credit-risk generator; also a Boltzmann-like
// distribution over {0,1}^n, matching the physical picture).
//
// Each institution i has a latent asset value
//     X_i = sum_f L[i][f] * Z_f  +  sigma_i * eps_i,    Z_f, eps_i ~ N(0,1)
// with sigma_i = sqrt(1 - sum_f L[i][f]^2) so that X_i ~ N(0,1).
// It "fails" when X_i < tau_i, where tau_i = Phi^{-1}(PD_i).
//
// Shared factor loadings create correlated failures. Each sector loads heavily
// on its OWN identity factor (so intra-sector correlation dominates -> the
// community structure is recoverable), lightly on macro/bank factors (the
// cross-sector contagion bridges), and OPPOSITE-SIGN loadings on a shared
// factor create the hedges (asset managers vs crypto / rates).
// ---------------------------------------------------------------------------

// factor layout
const F = {
  MACRO: 0,
  BANK: 1,
  RATES: 2,
  RISKON: 3,
  GB: 4,
  RB: 5,
  IN: 6,
  AM: 7,
  CR: 8,
} as const;
export const NUM_FACTORS = 9;

// human-facing names for the interpretable (non-identity) drivers
export const FACTOR_NAMES = ['Macro', 'Bank stress', 'Rates', 'Risk-on / Crypto'];

interface SectorSpec {
  key: string;
  name: string;
  count: number;
  pd: number;
  load: Partial<Record<keyof typeof F, number>>;
}

const SECTORS: SectorSpec[] = [
  { key: 'GB', name: 'Global Banks', count: 8, pd: 0.12, load: { MACRO: 0.18, BANK: 0.3, GB: 0.55 } },
  { key: 'RB', name: 'Regional Banks', count: 8, pd: 0.2, load: { MACRO: 0.18, BANK: 0.3, RATES: 0.3, RB: 0.55 } },
  { key: 'IN', name: 'Insurers', count: 8, pd: 0.14, load: { MACRO: 0.18, BANK: 0.25, IN: 0.55 } },
  { key: 'AM', name: 'Asset Managers', count: 8, pd: 0.07, load: { MACRO: 0.18, RATES: -0.3, RISKON: -0.45, AM: 0.58 } },
  { key: 'CR', name: 'Crypto / FinTech', count: 8, pd: 0.3, load: { MACRO: 0.18, RISKON: 0.35, CR: 0.6 } },
];

export interface Company {
  id: number;
  label: string;
  sector: string;
  sectorName: string;
  pd: number;
  load: number[];
}

function clamp(x: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, x));
}

function expand(spec: Partial<Record<keyof typeof F, number>>): number[] {
  const v = new Array<number>(NUM_FACTORS).fill(0);
  for (const k in spec) v[F[k as keyof typeof F]] = spec[k as keyof typeof F]!;
  return v;
}

export function buildCompanies(seed = 0x5eed): { companies: Company[]; hubId: number } {
  const rand = mulberry32(seed);
  const companies: Company[] = [];
  let id = 0;
  for (const s of SECTORS) {
    const base = expand(s.load);
    for (let k = 1; k <= s.count; k++) {
      // per-company jitter so nodes within a sector are not identical
      const load = base.map((v) => (v === 0 ? 0 : v + (rand() * 2 - 1) * 0.05));
      const pd = clamp(s.pd * Math.exp((rand() * 2 - 1) * 0.35), 0.02, 0.6);
      companies.push({ id, label: `${s.key}${k}`, sector: s.key, sectorName: s.name, pd, load });
      id++;
    }
  }

  // One global bank is a systemic hub: it loads on its own + the other banks'
  // identity and shared factors, so it co-moves with everything -> high
  // centrality, while its own PD stays moderate (systemic != fragile).
  const hubId = 0;
  companies[hubId].load = expand({ MACRO: 0.25, BANK: 0.45, GB: 0.45, RB: 0.25, IN: 0.25, RATES: 0.2, RISKON: 0.15 });
  companies[hubId].pd = 0.13;
  companies[hubId].label = 'GB1*';

  // keep idiosyncratic variance strictly positive
  for (const c of companies) {
    const s2 = c.load.reduce((a, v) => a + v * v, 0);
    if (s2 > 0.9) {
      const f = Math.sqrt(0.9 / s2);
      c.load = c.load.map((v) => v * f);
    }
  }
  return { companies, hubId };
}
