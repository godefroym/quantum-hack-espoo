import * as d3 from 'd3';
import './style.css';
import rawData from './data.json';
import { mulberry32 } from './rng';
import type { EdgeDatum, GraphData, Itemset, NodeDatum } from './types';

// Clone so d3-force can freely mutate node objects (x/y/vx/vy).
const data = structuredClone(rawData) as unknown as GraphData;
const { meta, nodes, edges } = data;

const LAYOUT_FLOOR = 0.05; // only reasonably-strong contagion edges shape the layout

// ---- palette & encodings ---------------------------------------------------
// Community hues are deliberately distinct from the red/blue edge axis.
const COMMUNITY_COLORS = [
  '#5ad1c8', '#f2b134', '#b39ddb', '#ef8aa8',
  '#9ccf5b', '#9aa7ff', '#e0825a', '#7fd17f',
];
const colorOf = (c: number): string => COMMUNITY_COLORS[c % COMMUNITY_COLORS.length];

const NEUTRAL: [number, number, number] = [108, 118, 140];
const HOT: [number, number, number] = [255, 84, 54];
const COLD: [number, number, number] = [56, 160, 255];

function edgeColor(phi: number): string {
  const scale = phi >= 0 ? meta.posPhiScale : meta.negPhiScale;
  const t = Math.min(1, Math.abs(phi) / (scale || 1));
  const base = phi >= 0 ? HOT : COLD;
  const k = 0.25 + 0.75 * t;
  const m = NEUTRAL.map((c, i) => Math.round(c + (base[i] - c) * k));
  return `rgb(${m[0]},${m[1]},${m[2]})`;
}

const marginals = nodes.map((d) => d.marginal);
const rScale = d3
  .scaleSqrt()
  .domain([Math.min(...marginals), Math.max(...marginals)])
  .range([6, 22]);
const edgeWidth = d3.scaleSqrt().domain([0, meta.maxAbsPhi]).range([0.5, 4]);

const coreR = (d: NodeDatum): number => rScale(d.marginal);
const haloR = (d: NodeDatum): number => coreR(d) + 3 + d.centrality * 14;
const haloOpacity = (d: NodeDatum): number => 0.08 + 0.2 * d.centrality;

// labels shown at rest: the systemically/structurally important nodes
const labelAlways = new Set<number>(
  [...nodes]
    .map((d) => ({ id: d.id, score: rScale(d.marginal) + d.centrality * 18 }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 14)
    .map((d) => d.id),
);

// ---- svg scaffold -----------------------------------------------------------
const svg = d3.select<SVGSVGElement, unknown>('#graph');
let W = window.innerWidth;
let H = window.innerHeight;
svg.attr('viewBox', `0 0 ${W} ${H}`);

const defs = svg.append('defs');
const glow = defs.append('filter').attr('id', 'glow').attr('x', '-80%').attr('y', '-80%').attr('width', '260%').attr('height', '260%');
glow.append('feGaussianBlur').attr('stdDeviation', 5);

const zoomG = svg.append('g');
const gEdges = zoomG.append('g');
const gNodes = zoomG.append('g');

// one gradient per edge: same hue, opacity ramps faint(driver) -> bright(dependent)
const grad = defs
  .selectAll('linearGradient.eg')
  .data(edges)
  .join('linearGradient')
  .attr('class', 'eg')
  .attr('id', (_d, i) => `eg${i}`)
  .attr('gradientUnits', 'userSpaceOnUse');
grad.append('stop').attr('offset', '0%').attr('stop-color', (d) => edgeColor(d.phi)).attr('stop-opacity', 0.1);
grad
  .append('stop')
  .attr('offset', '100%')
  .attr('stop-color', (d) => edgeColor(d.phi))
  .attr('stop-opacity', (d) => (d.phi < 0 ? 0.62 : 0.85)); // hedges recessive

const edgeSel = gEdges
  .selectAll<SVGLineElement, EdgeDatum>('line.edge')
  .data(edges)
  .join('line')
  .attr('class', 'edge')
  .attr('stroke', (_d, i) => `url(#eg${i})`)
  .attr('stroke-width', (d) => edgeWidth(Math.abs(d.phi)))
  .attr('stroke-dasharray', (d) => (d.phi < 0 ? '3 4' : null)) // dashed = hedge
  .on('mouseenter', (_ev, d) => {
    highlightEdge(d);
    showEdgeTip(d);
  })
  .on('mouseleave', () => {
    clearHighlight();
    hideTip();
  });

// ---- nodes ------------------------------------------------------------------
const drag = d3
  .drag<SVGGElement, NodeDatum>()
  .on('start', (ev, d) => {
    if (!ev.active) sim.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  })
  .on('drag', (ev, d) => {
    d.fx = ev.x;
    d.fy = ev.y;
  })
  .on('end', (ev, d) => {
    if (!ev.active) sim.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  });

const nodeG = gNodes
  .selectAll<SVGGElement, NodeDatum>('g.node')
  .data(nodes)
  .join('g')
  .attr('class', 'node')
  .call(drag)
  .on('mouseenter', (_ev, d) => {
    highlightNode(d);
    showNodeTip(d);
  })
  .on('mouseleave', () => {
    clearHighlight();
    hideTip();
  });

nodeG
  .append('circle')
  .attr('r', haloR)
  .attr('fill', (d) => colorOf(d.community))
  .attr('opacity', haloOpacity)
  .attr('filter', 'url(#glow)')
  .style('pointer-events', 'none');

nodeG
  .append('circle')
  .attr('class', 'node-core')
  .attr('r', coreR)
  .attr('fill', (d) => colorOf(d.community))
  .attr('stroke-width', (d) => 1 + d.centrality * 2.2)
  .attr('stroke-opacity', 0.85);

const labelSel = nodeG
  .append('text')
  .attr('class', 'node-label')
  .attr('text-anchor', 'middle')
  .attr('dy', (d) => -(coreR(d) + 5))
  .style('opacity', (d) => (labelAlways.has(d.id) ? 0.9 : 0))
  .text((d) => d.label);

// ---- forces -----------------------------------------------------------------
const numComm = Math.max(1, d3.max(nodes, (d) => d.community)! + 1);
const anchorR = Math.min(W, H) * 0.34;
// shift the field left of the 320px control panel so clusters never hide under it
const cx = (): number => W * 0.42;
const cy = (): number => H * 0.47;
const anchor = (c: number): { x: number; y: number } => {
  const a = -Math.PI / 2 + (2 * Math.PI * c) / numComm;
  return { x: cx() + anchorR * Math.cos(a), y: cy() + anchorR * Math.sin(a) };
};
const jitter = mulberry32(20260607);
for (const d of nodes) {
  const a = anchor(d.community);
  d.x = a.x + (jitter() - 0.5) * 90;
  d.y = a.y + (jitter() - 0.5) * 90;
}

interface SimLink {
  source: number | NodeDatum;
  target: number | NodeDatum;
  w: number;
}
const simLinks: SimLink[] = edges
  .filter((e) => e.phi >= LAYOUT_FLOOR)
  .map((e) => ({ source: e.source, target: e.target, w: e.phi }));

const wn = (w: number): number => Math.min(1, w / (meta.posPhiScale || 1));
const sim = d3
  .forceSimulation<NodeDatum>(nodes)
  .force(
    'link',
    d3
      .forceLink<NodeDatum, SimLink>(simLinks)
      .id((d) => d.id)
      .distance((l) => 42 + 95 * (1 - wn(l.w)))
      .strength((l) => 0.04 + 0.4 * wn(l.w)),
  )
  .force('charge', d3.forceManyBody<NodeDatum>().strength(-360).distanceMax(620))
  .force('collide', d3.forceCollide<NodeDatum>((d) => coreR(d) + 10).strength(0.9))
  .force('x', d3.forceX<NodeDatum>((d) => anchor(d.community).x).strength(0.08))
  .force('y', d3.forceY<NodeDatum>((d) => anchor(d.community).y).strength(0.08))
  .force('center', d3.forceCenter(cx(), cy()).strength(0.03))
  .on('tick', tick);

function tick(): void {
  edgeSel
    .attr('x1', (d) => nodes[d.source].x!)
    .attr('y1', (d) => nodes[d.source].y!)
    .attr('x2', (d) => nodes[d.target].x!)
    .attr('y2', (d) => nodes[d.target].y!);
  grad
    .attr('x1', (d) => nodes[d.source].x!)
    .attr('y1', (d) => nodes[d.source].y!)
    .attr('x2', (d) => nodes[d.target].x!)
    .attr('y2', (d) => nodes[d.target].y!);
  nodeG.attr('transform', (d) => `translate(${d.x},${d.y})`);
}

// ---- zoom -------------------------------------------------------------------
svg.call(
  d3
    .zoom<SVGSVGElement, unknown>()
    .scaleExtent([0.3, 5])
    .on('zoom', (ev) => zoomG.attr('transform', ev.transform.toString())),
);

// ---- interaction state & highlighting --------------------------------------
let threshold = meta.defaultThreshold;
let sign: 'all' | 'pos' | 'neg' = 'all';

// Contagion (up to ~0.5) and hedges (up to ~0.09) live on very different φ
// scales, so we filter on normalized strength — |φ| relative to its own
// per-sign scale — letting strong hedges and strong contagion compete fairly.
const strengthNorm = (e: EdgeDatum): number =>
  Math.abs(e.phi) / ((e.phi >= 0 ? meta.posPhiScale : meta.negPhiScale) || 1);

const edgeVisible = (e: EdgeDatum): boolean =>
  strengthNorm(e) >= threshold &&
  (sign === 'all' || (sign === 'pos' && e.phi > 0) || (sign === 'neg' && e.phi < 0));

function updateVisibility(): void {
  edgeSel.style('display', (d) => (edgeVisible(d) ? null : 'none'));
}

function highlightNode(d: NodeDatum): void {
  const inc = edges.filter((e) => (e.source === d.id || e.target === d.id) && edgeVisible(e));
  const nb = new Set<number>([d.id]);
  for (const e of inc) {
    nb.add(e.source);
    nb.add(e.target);
  }
  nodeG.style('opacity', (n) => (nb.has(n.id) ? 1 : 0.1));
  labelSel.style('opacity', (n) => (nb.has(n.id) ? 1 : 0));
  edgeSel.style('opacity', (e) => (edgeVisible(e) ? (e.source === d.id || e.target === d.id ? 1 : 0.04) : 0));
}

function highlightEdge(e: EdgeDatum): void {
  nodeG.style('opacity', (n) => (n.id === e.source || n.id === e.target ? 1 : 0.1));
  labelSel.style('opacity', (n) => (n.id === e.source || n.id === e.target ? 1 : 0));
  edgeSel.style('opacity', (x) => (edgeVisible(x) ? (x === e ? 1 : 0.04) : 0));
}

function highlightSet(ids: number[]): void {
  const set = new Set(ids);
  nodeG.style('opacity', (n) => (set.has(n.id) ? 1 : 0.08));
  labelSel.style('opacity', (n) => (set.has(n.id) ? 1 : 0));
  edgeSel.style('opacity', (e) => (edgeVisible(e) && set.has(e.source) && set.has(e.target) ? 1 : 0.03));
}

function clearHighlight(): void {
  nodeG.style('opacity', 1);
  labelSel.style('opacity', (n) => (labelAlways.has(n.id) ? 0.9 : 0));
  edgeSel.style('opacity', 1);
}

// ---- tooltip ----------------------------------------------------------------
const tip = d3.select('#tooltip');
const pct = (x: number): string => `${(x * 100).toFixed(1)}%`;

function blocsContaining(id: number): Itemset[] {
  return data.itemsets.filter((it) => it.members.includes(id)).slice(0, 2);
}

function showNodeTip(d: NodeDatum): void {
  const comm = data.communities[d.community];
  const blocs = blocsContaining(d.id);
  const blocHtml = blocs.length
    ? `<div class="tt-note">Top co-failure bloc: {${blocs[0].labels.join(', ')}} · ${pct(blocs[0].support)} of shots</div>`
    : '';
  tip.html(
    `<div class="tt-title">${d.label} · ${d.sectorName}</div>
     <div class="tt-row"><span>P(fails)</span><b>${pct(d.marginal)}</b></div>
     <div class="tt-row"><span>systemic centrality</span><b>${d.centrality.toFixed(2)}</b></div>
     <div class="tt-row"><span>detected bloc</span><b style="color:${colorOf(d.community)}">${comm.dominantSectorName}</b></div>
     ${blocHtml}`,
  );
  tip.classed('show', true);
}

function showEdgeTip(e: EdgeDatum): void {
  const s = nodes[e.source];
  const t = nodes[e.target];
  const contagion = e.phi > 0;
  const pill = contagion
    ? `<span class="pill" style="background:rgba(255,84,54,.18);color:#ff8a72">CONTAGION</span>`
    : `<span class="pill" style="background:rgba(56,160,255,.18);color:#7dc4ff">HEDGE</span>`;
  tip.html(
    `<div class="tt-title">${s.label} → ${t.label} ${pill}</div>
     <div class="tt-row"><span>φ correlation</span><b>${e.phi.toFixed(3)}</b></div>
     <div class="tt-row"><span>lift</span><b>${e.lift.toFixed(2)}×</b></div>
     <div class="tt-row"><span>P(both fail)</span><b>${pct(e.pBoth)}</b></div>
     <div class="tt-row"><span>P(${t.label} | ${s.label})</span><b>${pct(e.confST)}</b></div>
     <div class="tt-row"><span>P(${s.label} | ${t.label})</span><b>${pct(e.confTS)}</b></div>
     <div class="tt-note">${
       contagion
         ? `Fail together ${e.lift.toFixed(1)}× more than chance. Brightness flows ${s.label}→${t.label}: when the rarer one breaks, the other very likely follows.`
         : `Fail together ${e.lift.toFixed(2)}× chance — a hedge: one surviving tends to coincide with the other failing.`
     }</div>`,
  );
  tip.classed('show', true);
}

function hideTip(): void {
  tip.classed('show', false);
}

window.addEventListener('pointermove', (ev) => {
  const pad = 16;
  const node = tip.node() as HTMLElement;
  const w = node.offsetWidth;
  const h = node.offsetHeight;
  let x = ev.clientX + pad;
  let y = ev.clientY + pad;
  if (x + w > window.innerWidth) x = ev.clientX - w - pad;
  if (y + h > window.innerHeight) y = ev.clientY - h - pad;
  tip.style('left', `${x}px`).style('top', `${y}px`);
});

// ---- panel & legend ---------------------------------------------------------
function buildPanel(): void {
  const sectorOptions = data.communities;
  const commHtml = sectorOptions
    .map(
      (c) => `<div class="item" data-members="${c.members.join(',')}">
        <span class="swatch" style="background:${colorOf(c.id)};color:${colorOf(c.id)}"></span>
        <span class="lbl">${c.dominantSectorName}</span>
        <span class="meta">${c.size} · ${(c.purity * 100).toFixed(0)}% pure</span>
      </div>`,
    )
    .join('');

  const blocHtml = data.itemsets
    .slice(0, 12)
    .map(
      (it) => `<div class="item" data-members="${it.members.join(',')}">
        <span class="badge">${it.size}</span>
        <span class="lbl">${it.labels.join(' · ')}</span>
        <span class="meta">${pct(it.support)} · ${it.lift.toFixed(1)}×</span>
      </div>`,
    )
    .join('');

  d3.select('#panel').html(
    `<div class="title">Systemic Failure Network</div>
     <div class="subtitle">${meta.n} institutions · ${(meta.shots / 1000).toFixed(0)}k quantum shots · pairwise φ co-failure association</div>

     <div class="section">
       <div class="stat-grid">
         <div class="stat"><div class="v">${pct(meta.pNoFailure)}</div><div class="k">P(no failures)</div></div>
         <div class="stat"><div class="v">${meta.expectedFailures.toFixed(1)}</div><div class="k">avg simultaneous failures</div></div>
       </div>
     </div>

     <div class="section">
       <div class="section-h">Backbone — association strength ≥ <span class="slider-val" id="thv"></span></div>
       <input id="thr" type="range" min="0.02" max="1" step="0.01" />
       <div class="seg" id="signseg">
         <button data-sign="all" class="active">All</button>
         <button data-sign="pos">Contagion</button>
         <button data-sign="neg">Hedges</button>
       </div>
     </div>

     <div class="section">
       <div class="section-h">Detected blocs (Louvain)</div>
       <div class="list" id="commlist">${commHtml}</div>
     </div>

     <div class="section">
       <div class="section-h">Top co-failure baskets (Apriori)</div>
       <div class="list" id="bloclist">${blocHtml}</div>
     </div>`,
  );

  const thr = document.getElementById('thr') as HTMLInputElement;
  const thv = document.getElementById('thv')!;
  const fmtThresh = (): string => `${Math.round(threshold * 100)}%`;
  thr.value = String(threshold);
  thv.textContent = fmtThresh();
  thr.addEventListener('input', () => {
    threshold = +thr.value;
    thv.textContent = fmtThresh();
    updateVisibility();
  });

  document.querySelectorAll<HTMLButtonElement>('#signseg button').forEach((b) => {
    b.addEventListener('click', () => {
      sign = (b.dataset.sign as 'all' | 'pos' | 'neg') ?? 'all';
      document.querySelectorAll('#signseg button').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      updateVisibility();
    });
  });

  document.querySelectorAll<HTMLElement>('#commlist .item, #bloclist .item').forEach((el) => {
    const ids = el.dataset.members!.split(',').map(Number);
    el.addEventListener('mouseenter', () => highlightSet(ids));
    el.addEventListener('mouseleave', () => clearHighlight());
  });
}

function buildLegend(): void {
  d3.select('#legend').html(
    `<div class="section-h" style="margin-bottom:11px">How to read it</div>
     <div class="legend-row"><span class="lg-ico"><svg width="40" height="20"><circle cx="11" cy="10" r="4" fill="#9aa6bd"/><circle cx="30" cy="10" r="8" fill="#9aa6bd"/></svg></span><span class="txt"><b>Size</b> = P(this firm fails) — standalone fragility</span></div>
     <div class="legend-row"><span class="lg-ico"><svg width="40" height="22"><circle cx="20" cy="11" r="11" fill="#5ad1c8" opacity="0.28"/><circle cx="20" cy="11" r="5" fill="#5ad1c8"/></svg></span><span class="txt"><b>Glow</b> = systemic centrality — failure that radiates</span></div>
     <div class="legend-row"><span class="lg-ico"><svg width="40" height="20"><circle cx="11" cy="10" r="6" fill="#f2b134"/><circle cx="29" cy="10" r="6" fill="#b39ddb"/></svg></span><span class="txt"><b>Color</b> = data-detected failure bloc</span></div>
     <div style="margin-top:11px">
       <div class="edge-bar"></div>
       <div class="edge-scale"><span>hedge (anti-correlated)</span><span>contagion</span></div>
     </div>
     <div class="legend-row" style="margin-top:9px"><span class="lg-ico"><svg width="40" height="14"><line x1="4" y1="7" x2="36" y2="7" stroke="#ff5436" stroke-width="1"/><line x1="4" y1="7" x2="36" y2="7" stroke="#ff5436" stroke-width="0" /></svg></span><span class="txt"><b>Width</b> = |φ| strength · <b>brightness</b> flows driver→dependent</span></div>`,
  );
}

buildPanel();
buildLegend();
updateVisibility();

// ---- resize -----------------------------------------------------------------
window.addEventListener('resize', () => {
  W = window.innerWidth;
  H = window.innerHeight;
  svg.attr('viewBox', `0 0 ${W} ${H}`);
  sim.force('center', d3.forceCenter(cx(), cy()).strength(0.03));
  sim.force('x', d3.forceX<NodeDatum>((d) => anchor(d.community).x).strength(0.08));
  sim.force('y', d3.forceY<NodeDatum>((d) => anchor(d.community).y).strength(0.08));
  sim.alpha(0.3).restart();
});
