# Systemic Failure Network

An interactive **pairwise co-failure association graph** built from quantum-sampled
bitstrings. Each shot of the circuit is a string `s ∈ {0,1}ⁿ` where a `1` at
position *i* means institution *i* failed in that scenario. Over hundreds of
thousands of shots this is a probability distribution over the Boolean
hypercube; this page projects it to the legible **market-basket** view — treat
each shot as a "basket" of failed firms and draw the pairwise structure.

> The distribution is *not natively a graph* — a graph is a lossy projection of
> it. This is the descriptive/pairwise projection (option 2): faithful, legible,
> and honest about what it drops (higher-order blocs, surfaced separately).

## What you're looking at

Every visual channel carries meaning — nothing is decoration.

| Channel | Encodes |
| --- | --- |
| **Node size** | `P(this institution fails)` — standalone fragility (marginal) |
| **Node glow** | eigenvector centrality — *systemic* importance (failure that radiates) |
| **Node color** | data-detected community (Louvain) — the emergent failure bloc |
| **Edge color** | sign + strength of the φ correlation: warm = **contagion**, cool = **hedge** |
| **Edge style** | solid = contagion · dashed = hedge (anti-correlation) |
| **Edge width** | `|φ|` strength |
| **Edge brightness** | ramps **driver → dependent** — direction of implication `P(·|·)`, no arrowheads |

Fragility (size) and systemic importance (glow) are deliberately separate: the
scariest node is *robust but central* — small core, big halo. The planted
hub `GB1*` is exactly that.

### Controls
- **Backbone slider** — filter by normalized association strength (contagion and
  hedges live on ~5× different φ scales, so the cutoff is per-sign).
- **All / Contagion / Hedges** — isolate the sign of the relationship.
- **Detected blocs** — Louvain communities; hover to highlight.
- **Co-failure baskets** — Apriori frequent itemsets (the higher-order structure
  a pairwise graph drops); hover to highlight the members.
- Drag nodes · scroll to zoom · hover any node or edge for detail.

## How the synthetic data is made

The "quantum circuit" is stood in by a **Gaussian-copula factor model** of
correlated defaults — the standard credit-risk generator, and a Boltzmann-like
distribution over `{0,1}ⁿ`. Each institution has a latent
`Xᵢ = Σ_f Lᵢ_f Z_f + σᵢ εᵢ` and fails when `Xᵢ < Φ⁻¹(PDᵢ)`. Shared factor
loadings create correlated failures; **opposite-sign** loadings on a shared
factor create the hedges. Planted structure: five sectors with their own
identity factor (→ recoverable blocs), cross-bank contagion bridges, an
asset-manager / crypto flight-to-quality hedge, and one systemic hub.

The page **never sees the 300k raw shots**. The generator reduces them to
*sufficient statistics* — marginals, the φ matrix, conditionals, centrality,
communities, and the top co-failure baskets — and ships only that (`src/data.json`,
a few thousand numbers). The page must re-discover the planted structure (it
recovers all five sectors at 100% purity, and ranks the hub most central) from
the statistics alone.

## Run

```bash
npm install
npm run gen     # simulate the circuit -> src/data.json (deterministic)
npm run dev     # open the interactive page
```

`npm run build` regenerates the data, typechecks, and bundles to `dist/`.

## Layout

```
src/
  model.ts          planted factor model (sectors, loadings, the hub)
  rng.ts            seeded PRNG, normal sampler, inverse-normal CDF
  generate-data.ts  sample shots -> sufficient statistics -> data.json (+ report)
  analysis.ts       eigenvector centrality, Apriori itemset mining
  types.ts          the data contract
  main.ts           the interactive d3-force page
  style.css         dark glass UI
```
