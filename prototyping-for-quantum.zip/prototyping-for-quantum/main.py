def main():
    print("Hello from prototyping-for-quantum!")


if __name__ == "__main__":
    main()
